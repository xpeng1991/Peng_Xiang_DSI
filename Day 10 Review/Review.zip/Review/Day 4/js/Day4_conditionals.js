/*
 Xiang Peng
 Section 00
 7-14-15
 Conditionals
 */


//alert("Testing to see if this works");






