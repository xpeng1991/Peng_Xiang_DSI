/*
Xiang Peng
Section 00
7-11-15
Arrays
*/


//alert("alert");

// create a basic array
var arr = [50, 145, 10005];

//length property
console.log(arr.length);

// push - add to the end of the array
arr.push(45);

// pop - remove the last item of an array
// and returns it
arr.pop();


// splice - add or remove items in an array
// splice(position, number of items to remove, items to put in);

arr.splice(1, 1);
